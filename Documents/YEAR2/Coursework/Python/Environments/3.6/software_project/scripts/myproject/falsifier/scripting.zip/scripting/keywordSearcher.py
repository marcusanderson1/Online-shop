

def keywordSearcher(words):
    from datetime import datetime, timedelta
    searches = []

    words2 = words.split(",")

    reuterSearch = words2[0]+"+"+words2[1]+"+"+words2[2]+"+"+words2[3]+"+"+words2[4]
    indySearch = words2[0]+"%2520"+words2[1]+"%2520"+words2[2]+"%2520"+words2[3]+"%2520"+words2[4]
    skySearch = words2[0]+"%20"+words2[1]+"%20"+words2[2]+"%20"+words2[3]+"%20"+words2[4]





 # TO GET THE PROGRAM TO SEARCH WITHIN THE LAST THREE DAYS, THIS MUST BE IMPLEMENTED
 #    dateList = []
 #    today = datetime.date.today()
 #    dateList.append(today)
 #    threePrevious = datetime.date.today() - timedelta(days=3)
 #    dateList.append(threePrevious)
 #
 #    print(dateList[0])
 #    print(dateList[1])

    # Create a list of searches based on user input
    reuterUrl = "https://uk.reuters.com/search/news?blob=" + reuterSearch
    searches.append(reuterUrl)
    indyUrl = "http://www.independent.co.uk/search/site/" + indySearch
    searches.append(indyUrl)
    skyUrl = "https://news.sky.com/search?q=" + skySearch
    searches.append(skyUrl)

    return searches



# keywordSearcher()