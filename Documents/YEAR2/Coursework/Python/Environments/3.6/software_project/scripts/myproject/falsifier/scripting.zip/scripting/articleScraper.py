
# Sentdex youtube tut



from bs4 import BeautifulSoup
import urllib.request

def articleScraper(url):
    text = []
    #
    content = urllib.request.urlopen(url).read()
    #
    soup = BeautifulSoup(content, 'html.parser')

    # Print every paragraph found without the HTML tags.
    for paragraph in soup.find_all('p'):
        print(paragraph.string)
        text.append(paragraph)

    # Get the links of results
    # Independent: <li class = search-result>
    # Reuters: <div class=search-result-title a href>
    # Sky news: <a href= class="sdc-news-listing__link">
    # link = []

    # UNCOMMENT
    # for links in soup.find_all('div'): #class="search-result-content"):
    #     print(links)
    #     link.append(links)



#Tests
# works articleScraper("http://www.foxnews.com/politics/2018/01/08/trumps-twitter-typos-from-covfefe-to-unpresidented.html")
# works articleScraper("http://www.bbc.co.uk/sport/football/42860951")
# works articleScraper("https://uk.reuters.com/article/uk-britain-eu-ministers/eu-denies-britain-a-say-in-blocs-affairs-while-on-its-way-out-idUKKBN1FI1VF")
# works articleScraper("https://www.yahoo.com/news/trumps-state-union-will-answered-cacophony-resistance-voices-164313928.html")
# works articleScraper("http://www.independent.co.uk/news/uk/politics/gibraltar-brexit-veto-theresa-may-eu-deal-terms-chief-minister-fabian-picardo-spain-border-a8183946.html")