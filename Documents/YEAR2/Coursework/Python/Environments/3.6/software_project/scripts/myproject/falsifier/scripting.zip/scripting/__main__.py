


def main():
    import alexaScraper
    import articleScraper
    import keywordSearcher

    url = input("Enter url: ")
    words = input("Enter five keywords separated by commas: ")

    # TO deal with the URL ---
    # FUNCTION! articleScraper.articleScraper(url)
    alexaScraper.alexaScraper(url) # works

    # To deal with the keywords ------
    # Assigns the returned list of links to a variable to be later iterated through
    links = keywordSearcher.keywordSearcher(words) # works
    print(links)
    # For every link in the list, scrape the page (THIS WILL BE CHANGED TO A CRAWLER TO VISIT ALL RESULT LINKS0
    for i in links:
        articleScraper.articleScraper(i)






if __name__ == '__main__':
    # execute only if run as the entry point into the program
    main()