from bs4 import BeautifulSoup
import re
import urllib.request




def alexaScraper(url):

    alexa = "https://www.alexa.com/siteinfo/"
    # joins alexa string to user input
    join = alexa + url

    # Verifies that both strings have been joined successfully.
    print(join)

    # Opens the URL and reads the HTML text
    content = urllib.request.urlopen(join).read()


    soup = BeautifulSoup(content, 'html.parser')

    # Once inside the parsed HTML, find ALL <strong> tags.
    rank = soup.findAll("strong")

    # for r in rank:
    #     print(r.string)

    #to get rid of uneccesary text to leave the integers
    # for strong in soup.find_all('strong').isdigit():
    #     print(strong.string)

    # first number = global rank ***
    # second number = country rank ***
    # third number = bounce rate
    # fourth number = Daily page views per visitor ***
    # firth number = average time spent on site
    # sixth number = search visits

    # possible use of regular expressions to delete tags?
    # ranking = re.compile()


    print(rank)




