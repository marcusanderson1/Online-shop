# bbc search: https://www.bbc.co.uk/search?q=
# sky search: https://news.sky.com/search?q=  // (search by date)  https://news.sky.com/search?q=l&sortby=date
# cnn search: http://edition.cnn.com/search/?size=10&q=
# abc news weekly search: http://abcnews.go.com/search?searchtext=syria%20bomb&r=week